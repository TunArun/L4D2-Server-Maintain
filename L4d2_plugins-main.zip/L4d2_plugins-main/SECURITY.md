<details><summary>感谢以下大佬提供的插件, 爱来自开源❤❤❤</summary>

> 以下排名不分先后
<table>
  <tr>
  <td align="center">
		<a href="https://steamcommunity.com/id/sorallll">
			<img src="https://avatars.githubusercontent.com/u/49420198" width="60px;" alt="钵钵鸡"/>
			<p>sorallll</p>
		</a>
		<a href="https://github.com/umlka/l4d2">l4d2</a>
	</td>
	<td align="center">
		<a href="https://github.com/Target5150">
			<img src="https://avatars.githubusercontent.com/u/42076548" width="60px;" alt="Target5150"/>
			<p>Target5150</p>
		<a href="https://github.com/Target5150/MoYu_Server_Stupid_Plugins">MoYu_Server_Stupid_Plugins</a>
		</a>
	</td>
	<td align="center">
		<a href="https://github.com/Lin515">
			<img src="https://avatars.githubusercontent.com/u/35224561" width="60px;" alt="Lin515"/>
			<p>Lin515</p>
		<a href="https://github.com/Lin515/L4D_LinGe_Plugins">L4D2_LinGe_VScripts</a>
		</a>
	</td>
	<td align="center">
		<a href="https://github.com/fbef0102">
			<img src="https://avatars.githubusercontent.com/u/12229810" width="60px;" alt="fbef0102"/>
			<p>fbef0102</p>
		</a>
		<a href="https://github.com/fbef0102/L4D1_2-Plugins">L4D1_2-Plugins</a>
	</td>
	<td align="center">
		<a href="https://github.com/Caibiii">
			<img src="https://avatars.githubusercontent.com/u/64267950" width="60px;" alt="Caibiii"/>
			<p style="margin-bottom: 0;">Caibiii</p>
			<a href="https://github.com/Caibiii/AnneServer">AnneServer</a>
		</a>
	</td>
	</tr>
	<tr>
	<td align="center">
		<a href="https://github.com/fdxx">
			<img src="https://avatars.githubusercontent.com/u/44993923" width="60px;" alt="fdxx"/>
			<p>fdxx</p>
		</a>
		<a href="https://github.com/fdxx/l4d2_plugins">l4d2_plugins</a>
	</td>
	<td align="center">
		<a href="https://github.com/SilvDev">
			<img src="https://avatars.githubusercontent.com/u/6685181" width="60px;" alt="Silvers"/>
			<p>Silvers</p>
		</a>
		<a href="https://www.sourcemod.net/plugins.php?author=Silvers&search=1&sortby=title&order=0">his plugins</a>
	</td>
	<td align="center">
		<a href="https://github.com/SirPlease">
			<img src="https://avatars.githubusercontent.com/u/2643403" width="60px;" alt="SirPlease"/>
			<p>SirPlease</p>
		</a>
		<a href="https://github.com/SirPlease/L4D2-Competitive-Rework">L4D2-Competitive-Rework</a>
	</td>
	<td align="center">
		<a href="https://github.com/PencilMario">
			<img src="https://avatars.githubusercontent.com/u/72117241" width="60px;" alt="PencilMario"/>
			<p>PencilMario</p>
			</a>
		<a href="https://github.com/PencilMario/L4D2-Not0721Here-CoopSvPlugins">L4D2-Not0721Here-CoopSvPlugins</a>
	</td>
	<td align="center">
		<a href="https://github.com/fantasylidong">
			<img src="https://avatars.githubusercontent.com/u/22582796" width="60px;" alt="fantasylidong"/>
			<p>fantasylidong</p>
		</a>
		<a href="https://github.com/fantasylidong/CompetitiveWithAnne">L4D2-Not0721Here-CoopSvPlugins</a>
	</td>
	</tr>
	<tr>
	<td align="center">
		<a href="https://github.com/NanakaNeko">
			<img src="https://avatars.githubusercontent.com/u/81429435" width="60px;" alt="NanakaNeko"/>
			<p>NanakaNeko</p>
		</a>
		<a href="https://github.com/NanakaNeko/l4d2_plugins_coop">l4d2_plugins_coop</a>
	</td>
	<td align="center">
		<a href="https://github.com/accelerator74">
			<img src="https://avatars.githubusercontent.com/u/18032476" width="60px;" alt="accelerator74"/>
			<p>accelerator74</p>
		</a>
		<a href="https://github.com/accelerator74/sp-plugins">l4d2_plugins_coop</a>
	</td>
	<td align="center">
		<a href="https://github.com/GlowingTree880">
			<img src="https://avatars.githubusercontent.com/u/85665832" width="60px;" alt="GlowingTree880"/>
			<p>夜雨真白</p>
		</a>
		<a href="https://github.com/GlowingTree880/L4D2_LittlePlugins">L4D2_LittlePlugins</a>
	</td>
	<td align="center">
		<a href="https://github.com/txuk1x">
			<img src="https://cdn-fusion.imgimg.cc/i/2023/xzLEe175aEhb2A7u.jpg" width="60px;" alt="Kita"/>
			<p>Kita</p>
		</a>
		<a href="https://github.com/txuk1x/g10">g10</a>
	</td>
	<td align="center">
		<a href="https://github.com/Hatsune-Imagine">
			<img src="https://cdn-fusion.imgimg.cc/i/2023/efygQTyatPX1Q9uy.jpg" width="60px;" alt="Hatsune Imagine"/>
			<p>Hatsune Imagine</p>
		</a>
		<a href="https://github.com/Hatsune-Imagine/l4d2-plugins">l4d2-plugins</a>
	</td>
	</tr>
	<tr>
		<td align="center">
				<img src="https://cdn-fusion.imgimg.cc/i/2023/MpOZcjEy3hqU8Vzl.jpg" width="60px;" alt="豆瓣酱な"/>
				<p>豆瓣酱な</p>
				<p>妹有link捏</p>
		</td>
		<td align="center">
			<a href="https://github.com/apples1949">
				<img src="https://avatars.githubusercontent.com/u/49244656" width="60px;" alt="apples1949"/>
				<p>apples1949</p>
			<a href="https://github.com/apples1949/l4dplugins">l4dplugins</a>
		</td>
	</tr>
</table>
</details>