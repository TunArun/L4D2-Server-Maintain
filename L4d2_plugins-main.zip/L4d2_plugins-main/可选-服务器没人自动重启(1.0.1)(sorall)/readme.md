# 📌服务器没人自动重启

**原作 [Github](https://github.com/umlka/l4d2/tree/main/restart)**

> 修改源码myinfo

> 删除!rs指令
---
Command | 指令</summary>
<br>None

Image | 图示
<br>None

ConVar | 控制台变量
<br>None

Translation Support | 支持语言
<br>None

<details><summary>Apply to | 适用于</summary>

```php
L4D2
```
</details>

Require | 需求
<br>None

Related Plugin | 相关插件
<br>None

<details><summary>Changelog | 版本日志</summary>

- 2023.07.28
	- [手动重启不再检测服务器是否为空](https://github.com/umlka/l4d2/commit/518ce706724461213c2f22ece62ef93e97d598e4)
</details>