# 📌Alone单人模式+1vai
	
**原作 [Github](https://github.com/fantasylidong/CompetitiveWithAnne)**

Alone控制杀死特感并扣血, 1vai控制起身动画

> 修改Alone源码开局提示到服务器控制台, 修改部分提示文案
---
<details><summary>Command | 指令</summary>

|指令|功能|权限|
|-|-|-|
|`!alone`|手动开关单人模式|Console|
</details>

Video | 影片展示
<br>None

Image | 图示
<br>None

ConVar | 控制台变量
<br>None

<details><summary>Translation Support | 支持语言</summary>

```
简体中文
```
</details>

<details><summary>Apply to | 适用于</summary>

```php
L4D2
```
</details>

Require | 需求
<br>None

Related Plugin | 相关插件</summary>
<br>None

Changelog | 版本日志
<br>None