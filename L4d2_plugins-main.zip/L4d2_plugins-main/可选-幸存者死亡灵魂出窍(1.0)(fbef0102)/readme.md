# 📌幸存者死亡灵魂出窍

幸存者死亡会有透明灵魂升天, 使用电击器灵魂会回归尸体

**原作 [Github](https://github.com/fbef0102/L4D1_2-Plugins/tree/master/l4d_death_soul), 未修改**

---

Command | 指令
<br>None

<details><summary>Video | 影片展示</summary>

感谢哈利波特提供的视频 [YouTube](https://youtu.be/tSb1ayyhW0I)
</details>

<details><summary>Image | 图示</summary>

![l4d_death_soul_1](https://github.com/fbef0102/L4D1_2-Plugins/raw/master/l4d_death_soul/image/l4d_death_soul_1.gif)
</details>

<details><summary>ConVar | 控制台变量</summary>

cfg/sourcemod
```sourcepawn
// 0=关闭插件, 1=启用插件
// Default: "1"
l4d_death_soul_allow "1"
```
</details>

Translation Support | 支持语言
<br>None

<details><summary>Apply to | 适用于</summary>

```php
L4D1
L4D2
```
</details>

<details><summary>Require | 需求</summary>

1. [[L4D & L4D2] Left 4 DHooks Direct](https://forums.alliedmods.net/showthread.php?t=321696)
</details>

Related Plugin | 相关插件
<br>None

Changelog | 版本日志
<br>None