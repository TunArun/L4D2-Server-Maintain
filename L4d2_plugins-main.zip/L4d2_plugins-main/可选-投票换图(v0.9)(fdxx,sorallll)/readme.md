# 📌投票换图

**原作 [Github](https://github.com/fdxx/l4d2_plugins/blob/main/l4d2_map_vote.sp)**