# 📌战役回合重开延迟时间控制

**原作 [Github](https://github.com/umlka/l4d2/tree/main/coop_round_restart_delay)**

> 修改源码myinfo
---
Command | 指令
<br>None

Video | 影片展示
<br>None

Image | 图示
<br>None

<details><summary>ConVar | 控制台变量</summary>

no cfg
```sourcepawn
//Coop Round Restart Delay plugin version
coop_round_restart_delay_version

//战役回合重开延迟时间
coop_round_restart_delay "0.0"
```
</details>

Translation Support | 支持语言
<br>None

<details><summary>Apply to | 适用于</summary>

```php
L4D2
```
</details>

<details><summary>Require | 需求</summary>

1. [[L4D & L4D2] Left 4 DHooks Direct](https://forums.alliedmods.net/showthread.php?t=321696)
</details>

Related Plugin | 相关插件
<br>None

Changelog | 版本日志
<br>None