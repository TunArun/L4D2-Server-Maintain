# 📌AI Damage Fix | AI特感伤害修复

> 翻译很垃圾...

Replicate skeet mechanics on AI hunters
> 将 AI Hunter的射击机制模拟成撞靶运动
Negate the damage nerf on charging AI chargers
> 取消 AI Changer冲锋时的伤害削弱
Negate damage by scratches from stumbling AI SI
> 取消对 AI 特感造成僵直时的平A伤害

原作 [Github](https://github.com/Tabbernaut/L4D2-Plugins/tree/master/ai_damagefix)

---

