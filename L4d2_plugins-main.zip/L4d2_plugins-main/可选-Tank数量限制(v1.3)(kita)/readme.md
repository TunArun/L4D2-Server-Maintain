# 📌每一关的坦克数量限制
	
**原作 [Github](https://github.com/txuk1x/g10/tree/main/%E8%8D%AF%E5%BD%B9-tank%E6%95%B0%E9%87%8F%E9%99%90%E5%88%B6(kita)/left4dead2/addons/sourcemod)**

> 修改源码myinfo

---

Command | 指令
<br>None

Video | 影片展示
<br>None

Image | 图示
<br>None

<details><summary>ConVar | 控制台变量</summary>

```php
//本次关卡中坦克最多生成数量
z_tank_limit 1
```
</details>

<details><summary>Translation Support | 支持语言</summary>

```
简体中文
```
</details>

<details><summary>Apply to | 适用于</summary>

```php
L4D2
```
</details>

Require | 需求
<br>None

Related Plugin | 相关插件</summary>
<br>None

Changelog | 版本日志
<br>None