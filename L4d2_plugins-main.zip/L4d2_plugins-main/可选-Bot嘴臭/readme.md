# 📌bot会嘲讽杂鱼❤玩家

❗有刷屏风险

> 修改源码的文案
---
Command | 指令
<br>None

Video | 影片展示
<br>None

<details><summary>Image | 图示</summary>

![l4d2_botchat4.smx](imgs/01.jpg) ![l4d2_botchat4.smx](imgs/02.jpg)
</details>

ConVar | 控制台变量
<br>None

<details><summary>Translation Support | 支持语言</summary>

```
简体中文
```
</details>

<details><summary>Apply to | 适用于</summary>

```php
L4D2
```
</details>

Require | 需求
<br>None

Related Plugin | 相关插件
<br>None

Changelog | 版本日志
<br>None